#pragma once
#include<iostream>
using namespace std;
template<typename T>
class DLinkedList
{
public:
	DLinkedList();
	void AddToTail(const T&);
	void DeleteFromTail();
	void AddToHead(const T&);
	void DeleteFromHead();
	void Print();
	~DLinkedList();
	void shuffle();
	int returncount()
	{
		Node* temp = head;
		int count = 0;
		while (temp != nullptr)
		{
			temp = temp->next;
			count++;
		}
		return count;
	}

private:
	struct Node;
	Node* head, * tail;

	class ListIterator
	{
	private:
		Node* iptr;
	public:
		friend class DLinkedList<T>;
		ListIterator(Node* ptr = nullptr)
		{
			iptr = ptr;
		}
		ListIterator& operator++() {
			if (iptr) iptr = iptr->next;
			return (*this);
		}
		ListIterator operator++(int) {
			ListIterator old = *this;
			++(*this);
			return old;
		}

		ListIterator& operator--() {
			if (iptr) iptr = iptr->prev;
			return (*this);
		}
		ListIterator operator--(int) {
			ListIterator old = *this;
			--(*this);
			return old;
		}
		T& operator*() {
			return iptr->data;
		}
		bool operator==(const ListIterator& l) const
		{
			return iptr == l.iptr;
		}
		bool operator!=(const ListIterator& l) const {
			return !(iptr == l.iptr);
		}


	};

public:
	typedef ListIterator Iterator;
	Iterator begin()
	{
		Iterator I(head);
		return I;
	}
	Iterator end()
	{
		Iterator I(tail);
		return I;
	}
	void LinkAndDelink(DLinkedList& source, Iterator& ite)
	{
		if (ite != nullptr)
		{
			while (source.tail->data != *(ite))
			{
				source.tail = source.tail->prev;
			}
			if(tail!=nullptr)
			{
				tail->next = source.tail->next;
				tail->next->prev = tail;
			}
			else
			{
				head=tail = source.tail->next;
				tail->next = tail->prev = nullptr;
			}
			while (tail->next != nullptr)
			{
				tail = tail->next;
			}
			source.tail->next = nullptr;
		}
		else
		{
			tail->next = source.tail;
			tail->next->prev = tail;
			source.tail = nullptr;
			source.head = nullptr;
			while (tail->next != nullptr)
			{
				tail = tail->next;
			}
		}
		
	}
	void Link(Node* ptr)
	{
		if (tail == nullptr&&head==nullptr)
		{
			head = ptr;
			Node* temp = head;
			while (temp->next != nullptr)
				temp = temp->next;
			tail = temp;
			head->prev = nullptr;
			tail->next = nullptr;
		}
		else
		{
			tail->next = ptr;
			ptr->prev = tail;
			Node* temp = head;
			while (temp->next != nullptr)
				temp = temp->next;
			tail = temp;
		}

	}
	Node* Delink(Iterator& ite)
	{
		if (ite != nullptr)
		{
			if(head!=tail)
			{
				if (head->data == *ite)
				{
					Node* temp = head;
					head = nullptr;
					return temp;
				}
				while (tail->data != *ite)
				{
					tail = tail->prev;
				}
				tail = tail->prev;
				Node* temp = tail->next;
				temp->prev = nullptr;
				tail->next = nullptr;
				return temp;
			}
			else
			{
				Node* temp = head;
				head = tail = nullptr;
				return temp;
			}
		}
	}

};

template<class T>
struct DLinkedList<T>::Node
{
public:
	Node()
	{
		next = prev = 0;
	}

	Node(const T& val, Node* p = 0, Node* n = 0)
	{
		data = val;
		prev = p;
		next = n;
	}

	T data;
	Node* prev, * next;
};

template<class T>
DLinkedList<T>::DLinkedList()
{
	head = tail = nullptr;
}

template<class T>
void DLinkedList<T>::AddToHead(const T& val)
{
	if (head != nullptr)
	{
		Node* node = new Node(val, 0, head);
		head->prev = node;
		head = node;
	}
	else
		head = tail = new Node(val);
}

template<class T>
void DLinkedList<T>::AddToTail(const T& val)
{
	if (tail != nullptr)
	{
		Node* newnode = new Node(val, tail, 0);
		tail->next = newnode;
		tail = newnode;
	}
	else
		head = tail = new Node(val);
}

template<class T>
void DLinkedList<T>::DeleteFromHead()
{
	if (head != nullptr)
	{
		if (head == tail)
		{
			delete head;
			head = tail = 0;
		}
		else
		{
			head = head->next;
			delete head->prev;
			head->prev = 0;
		}
	}
	
}

template<class T>
void DLinkedList<T>::DeleteFromTail()
{
	if (head != nullptr)
	{
		if (head == tail)
		{
			delete head;
			head = tail = 0;
		}
		else
		{
			tail = tail->prev;
			delete tail->next;
			tail->next = 0;
		}
	}
}

template<class T>
DLinkedList<T>::~DLinkedList()
{
	if (head != nullptr)
	{
		if (head == tail)
		{
			delete head;
			head = tail = nullptr;
		}
		else
		{
			while (head != tail)
			{
				DeleteFromHead();
			}
			delete head;
			head = tail = nullptr;
		}
	}
}

template<class T>
void DLinkedList<T>::Print()
{
	Node* temp;
	for (temp = head; temp != NULL; temp = temp->next)
	{
		cout << temp->data << " ";
	}
	cout << endl;
}

template<typename T>
void DLinkedList<T>::shuffle() {
	if (head)
	{
		int count = 0;
		Node* current = head;
		while (current != nullptr)
		{
			count++;
			current = current->next;
		}
		srand(time(0));
		for (int i = 0; i < count; i++) 
		{
			int r1 = rand() % count;
			int r2 = rand() % count;

			if (r1 != r2)
			{
				Node* node1 = head;
				Node* node2 = head;

				for (int j = 0; j < r1; j++)
					node1 = node1->next;
				for (int j = 0; j < r2; j++)
					node2 = node2->next;


				/*Node* prev1 = node1->prev;
				Node* next1 = node1->next;
				Node* prev2 = node2->prev;
				Node* next2 = node2->next;

				if (prev1) prev1->next = node2;
				if (next1) next1->prev = node2;
				if (prev2) prev2->next = node1;
				if (next2) next2->prev = node1;

				node1->next = next2;
				node1->prev = prev2;
				node2->next = next1;
				node2->prev = prev1;

				if (node1 == head) head = node2;
				else if (node2 == head) head = node1;

				if (node1 == tail) tail = node2;
				else if (node2 == tail) tail = node1;*/

				swap(node1->data, node2->data);
			}
		}
	}
}

template<typename T>
class Stack
{
private:
	struct SLNode;
	SLNode* top;
	int count;
public:
	Stack()
	{
		top = nullptr;
		count = 0;
	}
	bool isEmpty()
	{
		return top == nullptr;
	}
	void push(T val)
	{
		top = new SLNode(val, top);
		count++;
	}
	int returncount()
	{
		return count;
	}
	T pop()
	{
		if (!isEmpty())
		{
			SLNode* temp = top;
			top = top->next;
			T retval = temp->val;
			delete temp;
			count--;
			return retval;
			
		}
	}
	T& peek()
	{
		if (!isEmpty())
		{
			return top->val;
		}
	}
	~Stack()
	{
		while (!isEmpty())
		{
			SLNode *temp = top;
			top = top->next;
			delete temp;
		}
	}
};

template<typename T>
class Stack<T>::SLNode
{
public:
	SLNode() 
	{
		next = NULL;
	}
	SLNode(T v, SLNode* nptr = 0)
	{
		val = v;
		next = nptr;

	}
	SLNode* next;
	T val;
};
#pragma once
#include<iostream>
using namespace std;
#define RED "\033[91m"
#define WHITE "\033[37m"
#define GREEN "\033[92m"
#define CYAN "\033[36m"
#define LIGHTCYAN "\033[95m"

enum suits                                    //enums for suits 0 for heart to 3 for diamond
{
	HEART=0,
	SPADE,
	CLUB,
	DIAMOND
};

enum ranks                                     //enums for ranks 0 for A to 12 for K
{
	A=0,
	TWO,
	THREE,
	FOUR,
	FIVE,
	SIX,
	SEVEN,
	EIGHT,
	NINE,
	TEN,
	J,
	Q,
	K
};

class Cards
{
	int suits;
	int ranks;
	bool isflipped;
public: 
	Cards()
	{
		suits = ranks = 0;
		isflipped = false;
	}
	bool isRed()const
	{
		if (suits == HEART || suits == DIAMOND)
			return true;
		else
			return false;
	}
	bool isBlack()const 
	{
		if (suits == CLUB || suits == SPADE)
			return true;
		else
			return false;
	}
	bool isFlipped()
	{
		return isflipped;
	}
	bool isLess( Cards& c2)
	{
		if (ranks == c2.ranks - 1)
			return true;
		else
			return false;
	}
	bool isGreater(Cards& c2)
	{
		if (ranks == c2.ranks + 1)
			return true;
		else
			return false;
	}
	bool isAlternating( Cards& c2)
	{
		if ((isRed() && c2.isBlack()) || (isBlack() && c2.isRed()))
		{
			return true;
		}
		return false;
	}
	bool isHeart()
	{
		return suits == 0;
	}
	bool isSpade()
	{
		return suits == 1;
	}
	bool isClub()
	{
		return suits == 2;
	}
	bool isDiamond()
	{
		return suits == 3;
	}
	bool isKing()
	{
		return ranks == 12;
	}
	bool isAce()
	{
		return ranks == 0;
	}
	Cards(int s, int r, bool status=false)
	{
		suits = s;
		ranks = r;
		isflipped = status;
	}
	void Flip()
	{
		if (!isflipped)
		{
			isflipped = true;
		}
		else
			isflipped = false;
	}
	void PrintCard()
	{
		if(isFlipped())
		{
			if (suits == HEART)
			{
				cout << RED;
				if (ranks == A)
					cout << "A" << "\u2665";
				if (ranks == TWO)
					cout << "2" << "\u2665";
				if (ranks == THREE)
					cout << "3" << "\u2665";
				if (ranks == FOUR)
					cout << "4" << "\u2665";
				if (ranks == FIVE)
					cout << "5" << "\u2665";
				if (ranks == SIX)
					cout << "6" << "\u2665";
				if (ranks == SEVEN)
					cout << "7" << "\u2665";
				if (ranks == EIGHT)
					cout << "8" << "\u2665";
				if (ranks == NINE)
					cout << "9" << "\u2665";
				if (ranks == TEN)
					cout << "10" << "\u2665";
				if (ranks == J)
					cout << "J" << "\u2665";
				if (ranks == Q)
					cout << "Q" << "\u2665";
				if (ranks == K)
					cout << "K" << "\u2665";
				cout << WHITE;
			}
			else if (suits == SPADE)
			{
				if (ranks == A)
					cout << "A" << "\u2660";
				if (ranks == TWO)
					cout << "2" << "\u2660";
				if (ranks == THREE)
					cout << "3" << "\u2660";
				if (ranks == FOUR)
					cout << "4" << "\u2660";
				if (ranks == FIVE)
					cout << "5" << "\u2660";
				if (ranks == SIX)
					cout << "6" << "\u2660";
				if (ranks == SEVEN)
					cout << "7" << "\u2660";
				if (ranks == EIGHT)
					cout << "8" << "\u2660";
				if (ranks == NINE)
					cout << "9" << "\u2660";
				if (ranks == TEN)
					cout << "10" << "\u2660";
				if (ranks == J)
					cout << "J" << "\u2660";
				if (ranks == Q)
					cout << "Q" << "\u2660";
				if (ranks == K)
					cout << "K" << "\u2660";
			}
			else if (suits == CLUB)
			{
				if (ranks == A)
					cout << "A" << "\u2663";
				if (ranks == TWO)
					cout << "2" << "\u2663";
				if (ranks == THREE)
					cout << "3" << "\u2663";
				if (ranks == FOUR)
					cout << "4" << "\u2663";
				if (ranks == FIVE)
					cout << "5" << "\u2663";
				if (ranks == SIX)
					cout << "6" << "\u2663";
				if (ranks == SEVEN)
					cout << "7" << "\u2663";
				if (ranks == EIGHT)
					cout << "8" << "\u2663";
				if (ranks == NINE)
					cout << "9" << "\u2663";
				if (ranks == TEN)
					cout << "10" << "\u2663";
				if (ranks == J)
					cout << "J" << "\u2663";
				if (ranks == Q)
					cout << "Q" << "\u2663";
				if (ranks == K)
					cout << "K" << "\u2663";
			}
			else if (suits == DIAMOND)
			{
				cout << RED;
				if (ranks == A)
					cout << "A" << "\u2666";
				if (ranks == TWO)
					cout << "2" << "\u2666";
				if (ranks == THREE)
					cout << "3" << "\u2666";
				if (ranks == FOUR)
					cout << "4" << "\u2666";
				if (ranks == FIVE)
					cout << "5" << "\u2666";
				if (ranks == SIX)
					cout << "6" << "\u2666";
				if (ranks == SEVEN)
					cout << "7" << "\u2666";
				if (ranks == EIGHT)
					cout << "8" << "\u2666";
				if (ranks == NINE)
					cout << "9" << "\u2666";
				if (ranks == TEN)
					cout << "10" << "\u2666";
				if (ranks == J)
					cout << "J" << "\u2666";
				if (ranks == Q)
					cout << "Q" << "\u2666";
				if (ranks == K)
					cout << "K" << "\u2666";
				cout << WHITE;
			}
		}
		else
			cout << "[ ]";
	}

	/*Cards(const Cards& card)
	{
		suits = card.suits;
		ranks = card.ranks;
	}

	Cards& operator=(const Cards& c)
	{
		suits = c.suits;
		ranks = c.ranks;
		return *this;
	}*/
	friend ostream& operator<<(ostream&, Cards& );

};

inline ostream& operator<<(ostream& out, Cards& card)                         //operator<< to print a certain card;
{
	
	card.PrintCard();
	return out;
}
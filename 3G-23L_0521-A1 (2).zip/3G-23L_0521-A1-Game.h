#pragma once
#include"3G-23L_0521-A1-Header.h"
#include"3G-23L_0521-A1-Cards.h"
#include<iostream>
#include<string>
using namespace std;
class Game
{
private:
	class Command;
	DLinkedList<Cards*> Deck;
	DLinkedList<Cards*> Columns[7];
	Stack<Cards*> Stockpile;
	Stack<Cards*> Wastepile;
	Stack<Cards*> Foundation[4];
	Stack<Command> commands;
	static Game* instance;
	class Command
	{
	public:
		friend class Game;
		char operation;
		string source;
		string destination;
		int number;
		Command()
		{

		}

		Command(const Command& c)
		{
			operation = c.operation;
			source = c.source;
			destination = c.destination;
			number = c.number;
		}

		Command(char op, string src, string dest, int num)
		{
			operation = op;
			source = src;
			destination = dest;
			number = num;
		}

		void undo()
		{
			swap(source, destination);
		}

	};
	Game()
	{

	}
public:
	static Game* getInstance()                                  //singleton implementation
	{
		if (instance == nullptr)
			instance = new Game;
		return instance;
	}                                                

	~Game()                                //Destroys all the cards
	{
		DLinkedList<Cards*>::Iterator ite = Deck.begin();
		while (ite != nullptr)
		{
			delete* ite;
			ite++;
		}
	}

	void initialize()                           //shuffles and arranges cards to columns and stock
	{
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 13; j++)
			{
				Cards * c = new Cards(i, j);
				Deck.AddToTail(c);
			}
		}

		Deck.shuffle();

		DLinkedList<Cards*>::Iterator ite = Deck.begin();
		for (int i = 0; i < 7; i++)
		{
			for (int j = 0; j < i + 1; j++)
			{
				Columns[i].AddToTail(*ite);
				ite++;
			}
			ite--;
			(*ite)->Flip();
			ite++;
		}

		for (; ite != nullptr; ite++)
		{
			Stockpile.push(*ite);
		}
	}

	void printBoard()                             //prints the interface
	{
		cout << "\t\t\t\t\t\t\t " << RED << "S" << GREEN << "O" << WHITE << "L" << RED << "I" << GREEN << "T" << WHITE << "A" << RED << "I" << GREEN << "R" << WHITE<<"E\t\t\n\n\n";
		cout <<RED << "Game Rules/ Useful Commands: \n"<<WHITE;
		cout << "1. Use" << GREEN << " Z "<<WHITE<< "To Undo\n";
		cout << "2. Use" << GREEN << " M " << WHITE << "To Move (column to column, column to foundation, waste to column, waste to foundation, foundation to column)\n";
		cout << "3. Use" << GREEN << " S " << WHITE << "To Draw from StockPile to Wastepile\n";
		cout << "4. Use" << GREEN << " Q " << WHITE << "To Quit game\n";
		cout <<CYAN<< "\n\n\nStock\t\tWaste\t\t\t\t";
		for (int i = 0; i < 4; i++)
		{
			cout << "Foundation " << i + 1 << "\t";
		}
		cout<<WHITE << endl;
		if (!Stockpile.isEmpty())
		{
			cout << "[ ]" << "\t\t";
		}
		else
			cout << "\t\t";
		if (!Wastepile.isEmpty())
		{
			cout << *(Wastepile.peek()) << "\t\t\t\t";
		}
		else
			cout << "[   ]\t\t\t\t";

		for (int i = 0; i < 4; i++)
		{
			if (!Foundation[i].isEmpty())
				cout << *(Foundation[i].peek()) << "\t\t";
			else
				cout << "[   ]\t\t";
		}
		cout << endl;

		cout <<LIGHTCYAN<< "(" << Stockpile.returncount() << " cards)\t";
		cout << "(" << Wastepile.returncount() << " cards)\t\t\t";
		for (int i = 0; i < 4; i++)
		{
			cout << "(" << Foundation[i].returncount() << " cards)\t";
		}
		cout <<WHITE<< endl;
		cout << endl;
		DLinkedList<Cards*> ::Iterator ite [7] ;
		cout << CYAN;
		for (int i = 0; i < 7; i++)
		{
			cout << "Column " << i + 1 << "\t";
		}
		cout <<WHITE<< endl;
		cout << LIGHTCYAN;
		for (int i = 0; i < 7; i++)
		{
			cout << "(" << Columns[i].returncount() << " Cards)\t";
			ite[i] = Columns[i].begin();
		}
		cout <<WHITE<< endl;
		int maxcol = 0;
		int maxcount = 0;
		for (int i = 0; i < 7; i++)
		{
			if (maxcount <= Columns[i].returncount())
			{
				maxcount = Columns[i].returncount();
				maxcol = i;
			}
		}
		while (ite[maxcol] != nullptr)
		{
			for (int i = 0; i < 7; i++)
			{
				if (ite[i] != nullptr)
				{
						cout << *(*ite[i]) << "\t\t";
				}
				else
					cout << "\t\t";
				ite[i]++;
			}
			cout << endl;
		}
	}

	bool Move(Command &c1)                             //Move function. calls necessary unlink and link or push and pop functions
	{
		if (c1.operation == 's')
		{
			Cards* temp = Stockpile.pop();
			if(!temp->isFlipped())
				temp->Flip();
			Wastepile.push(temp);

		}
		else if (c1.operation == 'm')
		{
			DLinkedList<Cards*>::Iterator src, dest;
			DLinkedList<Cards*> *Destination=nullptr;
			DLinkedList<Cards*> *Source=nullptr;
			Stack<Cards*>* sorc = nullptr;

			if (c1.source == "c1")
			{
				src = Columns[0].end();
				Source =&Columns[0];
			}
			else if (c1.source == "c2")
			{
				src = Columns[1].end();
				Source = &Columns[1];
			}
			else if (c1.source == "c3")
			{
				src = Columns[2].end();
				Source = &Columns[2];
			}
			else if (c1.source == "c4")
			{
				src = Columns[3].end();
				Source = &Columns[3];
			}
			else if (c1.source == "c5")
			{
				src = Columns[4].end();
				Source = &Columns[4];
			}
			else if (c1.source == "c6")
			{
				src = Columns[5].end();
				Source = &Columns[5];
			}
			else if (c1.source == "c7")
			{
				src = Columns[6].end();
				Source = &Columns[6];
			}


			if (c1.destination == "c1")
			{
				dest = Columns[0].end();
				Destination = &Columns[0];
			}
			else if (c1.destination == "c2")
			{
				dest = Columns[1].end();
				Destination = &Columns[1];
			}
			else if (c1.destination == "c3")
			{
				dest = Columns[2].end();
				Destination = &Columns[2];
			}
			else if (c1.destination == "c4")
			{
				dest = Columns[3].end();
				Destination = &Columns[3];
			}
			else if (c1.destination == "c5")
			{
				dest = Columns[4].end();
				Destination = &Columns[4];
			}
			else if (c1.destination == "c6")
			{
				dest = Columns[5].end();
				Destination = &Columns[5];
			}
			else if (c1.destination == "c7")
			{
				dest = Columns[6].end();
				Destination = &Columns[6];
			}

			if (c1.source == "f1")
			{
				sorc = &Foundation[0];
				if ((sorc->peek())->isKing() && Destination->returncount() == 0)
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				if ((sorc->peek())->isLess(*(*dest)) && (sorc->peek())->isAlternating(*(*dest)))
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				return false;
			}
			if (c1.source == "f2")
			{
				sorc = &Foundation[1];
				if ((sorc->peek())->isKing() && Destination->returncount() == 0)
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				if ((sorc->peek())->isLess(*(*dest)) && (sorc->peek())->isAlternating(*(*dest)))
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				return false;
			}
			if (c1.source == "f3")
			{
				sorc = &Foundation[2];
				if ((sorc->peek())->isKing() && Destination->returncount() == 0)
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				if ((sorc->peek())->isLess(*(*dest)) && (sorc->peek())->isAlternating(*(*dest)))
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				return false;
			}
			if (c1.source == "f4")
			{
				sorc = &Foundation[3];
				if ((sorc->peek())->isKing() && Destination->returncount() == 0)
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				if ((sorc->peek())->isLess(*(*dest)) && (sorc->peek())->isAlternating(*(*dest)))
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				return false;
			}
			if (c1.source == "w")
			{
				if (c1.destination == "f")
				{
					if ((Wastepile.peek())->isHeart())
					{
						c1.destination = c1.destination + "1";
						if (Foundation[0].isEmpty())
						{
							if ((Wastepile.peek())->isAce())
							{
								Foundation[0].push((Wastepile.pop()));
								return true;
							}
						}
						else if ((Wastepile.peek())->isGreater(*(Foundation[0].peek())))
						{
							Foundation[0].push((Wastepile.pop()));
							return true;
						}
					}
					else if ((Wastepile.peek())->isSpade())
					{
						c1.destination = c1.destination + "2";
						if (Foundation[1].isEmpty())
						{
							if ((Wastepile.peek())->isAce())
							{
								Foundation[1].push((Wastepile.pop()));
								return true;
							}
						}
						else if ((Wastepile.peek())->isGreater(*(Foundation[1].peek())))
						{
							Foundation[1].push((Wastepile.pop()));
							return true;
						}
					}
					else if ((Wastepile.peek())->isClub())
					{
						c1.destination = c1.destination + "3";
						if (Foundation[2].isEmpty())
						{
							if ((Wastepile.peek())->isAce())
							{
								Foundation[2].push((Wastepile.pop()));
								return true;
							}
						}
						else if ((Wastepile.peek())->isGreater(*(Foundation[2].peek())))
						{
							Foundation[2].push((Wastepile.pop()));
							return true;
						}
					}
					else if ((Wastepile.peek())->isDiamond())
					{
						c1.destination = c1.destination + "4";
						if (Foundation[3].isEmpty())
						{
							if ((Wastepile.peek())->isAce())
							{
								Foundation[3].push((Wastepile.pop()));
								return true;
							}
						}
						else if ((Wastepile.peek())->isGreater(*(Foundation[3].peek())))
						{
							Foundation[3].push((Wastepile.pop()));
							return true;
						}
					}
					return false;

				}
				sorc = &Wastepile;
				if ((sorc->peek())->isKing() && Destination->returncount() == 0)
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				if ((sorc->peek())->isLess(*(*dest)) && (sorc->peek())->isAlternating(*(*dest)))
				{
					Destination->AddToTail(sorc->pop());
					return true;
				}
				return false;
			}

			if (c1.destination == "f")
			{
				if((*src)->isHeart())
				{
					c1.destination = c1.destination + "1";
					if (Foundation[0].isEmpty())
					{
						if ((*src)->isAce())
						{
							Foundation[0].push((*src));
							if(Source->returncount()>1)
							{
								if (*--src != nullptr && !(*src)->isFlipped())
									(*src)->Flip();
							}
							Source->DeleteFromTail();
							return true;
						}
					}
					else if ((*src)->isGreater(*(Foundation[0].peek())))
					{
						Foundation[0].push((*src));
						if (Source->returncount() > 1)
						{
							if (*--src != nullptr && !(*src)->isFlipped())
								(*src)->Flip();
						}
						Source->DeleteFromTail();
						return true;
					}
				}
				else if ((*src)->isSpade())
				{
					c1.destination = c1.destination + "2";
					if (Foundation[1].isEmpty())
					{
						if ((*src)->isAce())
						{
							Foundation[1].push((*src));
							if (Source->returncount() > 1)
							{
								if (*--src != nullptr && !(*src)->isFlipped())
									(*src)->Flip();
							}
							Source->DeleteFromTail();
							return true;
						}
					}
					else if ((*src)->isGreater(*(Foundation[1].peek())))
					{
						Foundation[1].push((*src));
						if (Source->returncount() > 1)
						{
							if (*--src != nullptr && !(*src)->isFlipped())
								(*src)->Flip();
						}
						Source->DeleteFromTail();
						return true;
					}
				}
				else if ((*src)->isClub())
				{
					c1.destination = c1.destination + "3";
					if (Foundation[2].isEmpty())
					{
						if ((*src)->isAce())
						{
							Foundation[2].push((*src));
							if (Source->returncount() > 1)
							{
								if (*--src != nullptr && !(*src)->isFlipped())
									(*src)->Flip();
							}
							Source->DeleteFromTail();
							return true;
						}
					}
					else if ((*src)->isGreater(*(Foundation[2].peek())))
					{
						Foundation[2].push((*src));
						if (Source->returncount() > 1)
						{
							if (*--src != nullptr && !(*src)->isFlipped())
								(*src)->Flip();
						}
						Source->DeleteFromTail();
						return true;
					}
				}
				else if ((*src)->isDiamond())
				{
					c1.destination = c1.destination + "4";
					if (Foundation[3].isEmpty())
					{
						if ((*src)->isAce())
						{
							Foundation[3].push((*src));
							if (Source->returncount() > 1)
							{
								if (*--src != nullptr && !(*src)->isFlipped())
									(*src)->Flip();
							}
							Source->DeleteFromTail();
							return true;
						}
					}
					else if ((*src)->isGreater(*(Foundation[3].peek())))
					{
						Foundation[3].push((*src));
						if (Source->returncount() > 1)
						{
							if (*--src != nullptr && !(*src)->isFlipped())
								(*src)->Flip();
						}
						Source->DeleteFromTail();
						return true;
					}
				}
				return false;
			}

			if (c1.number > Source->returncount())
				return false;
			else
			{
				for (int i = 0; i < c1.number - 1; i++)
				{
					src--;
				}
			}

			if (Destination->returncount() == 0 && (*src)->isKing())
			{
				Destination->Link(Source->Delink(src));
				if (c1.source == "c1")
				{
					src = Columns[0].end();
				}
				else if (c1.source == "c2")
				{
					src = Columns[1].end();
				}
				else if (c1.source == "c3")
				{
					src = Columns[2].end();
				}
				else if (c1.source == "c4")
				{
					src = Columns[3].end();
				}
				else if (c1.source == "c5")
				{
					src = Columns[4].end();
				}
				else if (c1.source == "c6")
				{
					src = Columns[5].end();
				}
				else if (c1.source == "c7")
				{
					src = Columns[6].end();
				}
				if (src != nullptr && !(*src)->isFlipped())
				{
					(*src)->Flip();
				}
				return true;
			}
			if ((*src)->isLess(*(*dest)) && (*src)->isAlternating(*(*dest)))
			{

				Destination->Link(Source->Delink(src));

				//(*Destination).LinkAndDelink(*Source, --src);
				if (src != nullptr && !(*src)->isFlipped())
				{
					(*src)->Flip();
				}
				if (c1.source == "c1")
				{
					src = Columns[0].end();
				}
				else if (c1.source == "c2")
				{
					src = Columns[1].end();
				}
				else if (c1.source == "c3")
				{
					src = Columns[2].end();
				}
				else if (c1.source == "c4")
				{
					src = Columns[3].end();
				}
				else if (c1.source == "c5")
				{
					src = Columns[4].end();
				}
				else if (c1.source == "c6")
				{
					src = Columns[5].end();
				}
				else if (c1.source == "c7")
				{
					src = Columns[6].end();
				}
				if (src != nullptr && !(*src)->isFlipped())
				{
					(*src)->Flip();
				}
				return true;
			}
			return false;
		}
	}

	void StackUndo(Stack<Cards*>* src, Stack<Cards*>* dest)
	{
		dest->push(src->pop());
	}                

	void moveundo(Command& c1)                            //same as move but for undo commands
	{
		DLinkedList<Cards*>::Iterator src, dest;
		DLinkedList<Cards*>* Destination = nullptr;
		DLinkedList<Cards*>* Source = nullptr;
		Stack<Cards*>* stock = nullptr;
		Stack<Cards*>* waste = nullptr;

		if (c1.source == "w" && c1.destination=="s")
		{
			stock = &Stockpile;
			waste = &Wastepile;

			StackUndo(waste, stock);
			return;
		}
		if (c1.source == "c1")
		{
			src = Columns[0].end();
			Source = &Columns[0];
		}
		else if (c1.source == "c2")
		{
			src = Columns[1].end();
			Source = &Columns[1];
		}
		else if (c1.source == "c3")
		{
			src = Columns[2].end();
			Source = &Columns[2];
		}
		else if (c1.source == "c4")
		{
			src = Columns[3].end();
			Source = &Columns[3];
		}
		else if (c1.source == "c5")
		{
			src = Columns[4].end();
			Source = &Columns[4];
		}
		else if (c1.source == "c6")
		{
			src = Columns[5].end();
			Source = &Columns[5];
		}
		else if (c1.source == "c7")
		{
			src = Columns[6].end();
			Source = &Columns[6];
		}

		if (c1.source[0] == 'c' && c1.destination == "w")
		{
			Wastepile.push(*(src));
			Source->Delink(src);
			return;
		}
		if (c1.source[0] == 'c' && c1.destination == "f1")
		{
			Foundation[0].push(*(src));
			Source->Delink(src);
			return;
		}
		if (c1.source[0] == 'c' && c1.destination == "f2")
		{
			Foundation[1].push(*(src));
			Source->Delink(src);
			return;
		}
		if (c1.source[0] == 'c' && c1.destination == "f3")
		{
			Foundation[2].push(*(src));
			Source->Delink(src);
			return;
		}
		if (c1.source[0] == 'c' && c1.destination == "f4")
		{
			Foundation[3].push(*(src));
			Source->Delink(src);
			return;
		}
		if (c1.destination == "c1")
		{
			dest = Columns[0].end();
			Destination = &Columns[0];
		}
		else if (c1.destination == "c2")
		{
			dest = Columns[1].end();
			Destination = &Columns[1];
		}
		else if (c1.destination == "c3")
		{
			dest = Columns[2].end();
			Destination = &Columns[2];
		}
		else if (c1.destination == "c4")
		{
			dest = Columns[3].end();
			Destination = &Columns[3];
		}
		else if (c1.destination == "c5")
		{
			dest = Columns[4].end();
			Destination = &Columns[4];
		}
		else if (c1.destination == "c6")
		{
			dest = Columns[5].end();
			Destination = &Columns[5];
		}
		else if (c1.destination == "c7")
		{
			dest = Columns[6].end();
			Destination = &Columns[6];
		}

		if (c1.source == "f1")
		{
			if (c1.destination == "w")
			{
				Wastepile.push(Foundation[0].pop());
				return;
			}
			if(Destination->returncount()>0)
			{
				(*dest)->Flip();
			}
			Destination->AddToTail(Foundation[0].pop());
			return;
		}
		else if (c1.source == "f2")
		{
			if (c1.destination == "w")
			{
				Wastepile.push(Foundation[1].pop());
				return;
			}
			if (Destination->returncount() > 0)
			{
				(*dest)->Flip();
			}
			Destination->AddToTail(Foundation[1].pop());
			return;
		}
		else if (c1.source == "f3")
		{
			if (c1.destination == "w")
			{
				Wastepile.push(Foundation[2].pop());
				return;
			}
			if (Destination->returncount() > 0)
			{
				(*dest)->Flip();
			}
			Destination->AddToTail(Foundation[2].pop());
			return;
		}
		else if (c1.source == "f4")
		{
			if (c1.destination == "w")
			{
				Wastepile.push(Foundation[3].pop());
				return;
			}
			if (Destination->returncount() > 0)
			{
				(*dest)->Flip();
			}
			Destination->AddToTail(Foundation[3].pop());
			return;
		}

		for (int i = 0; i < c1.number - 1; i++)
		{
			src--;
		}
		if (c1.destination == "c1")
		{
			dest = Columns[0].end();
			Destination = &Columns[0];
		}
		else if (c1.destination == "c2")
		{
			dest = Columns[1].end();
			Destination = &Columns[1];
		}
		else if (c1.destination == "c3")
		{
			dest = Columns[2].end();
			Destination = &Columns[2];
		}
		else if (c1.destination == "c4")
		{
			dest = Columns[3].end();
			Destination = &Columns[3];
		}
		else if (c1.destination == "c5")
		{
			dest = Columns[4].end();
			Destination = &Columns[4];
		}
		else if (c1.destination == "c6")
		{
			dest = Columns[5].end();
			Destination = &Columns[5];
		}
		else if (c1.destination == "c7")
		{
			dest = Columns[6].end();
			Destination = &Columns[6];
		}
		if (dest != nullptr && (*dest)->isFlipped())
		{
			(*dest)->Flip();
		}
		Destination->Link(Source->Delink(src));
		//(*Destination).LinkAndDelink(*Source, --src);
		if (src != nullptr && !(*src)->isFlipped())
		{
			(*src)->Flip();
		}
		if (c1.source == "c1")
		{
			src = Columns[0].end();
		}
		else if (c1.source == "c2")
		{
			src = Columns[1].end();
		}
		else if (c1.source == "c3")
		{
			src = Columns[2].end();
		}
		else if (c1.source == "c4")
		{
			src = Columns[3].end();
		}
		else if (c1.source == "c5")
		{
			src = Columns[4].end();
		}
		else if (c1.source == "c6")
		{
			src = Columns[5].end();
		}
		else if (c1.source == "c7")
		{
			src = Columns[6].end();
		}
		if (src != nullptr && !(*src)->isFlipped())
		{
			(*src)->Flip();
		}
		

	}

	void run()                                   //initializes the decks, parse commands, checks for win etc
	{
		initialize();
		while (Foundation[0].returncount() != 13 && Foundation[1].returncount() != 13 && Foundation[2].returncount() != 13 && Foundation[3].returncount() != 13)
		{
			string comm;
			printBoard();
			cout << "Enter Your Command : ";
			getline(cin, comm);
			if (comm == "q")
			{
				return;
			}
			else if (comm == "rs")
			{
				system("cls");
				while (!Wastepile.isEmpty())
				{
					Stockpile.push(Wastepile.pop());
				}
			}
			else if (comm[0] == 'z')
			{
				if (!commands.isEmpty())
				{
					Command undocommand(commands.pop());
					undocommand.undo();
					moveundo(undocommand);
					system("cls");
				}
				else
				{
					system("cls");
					cout << RED << "Invalid Operation. Cannot Perform more undo :(\n\n" << WHITE;
				}
			}
			else if (comm[0] == 's')
			{
				if (!Stockpile.isEmpty())
				{
					Command StockMove('s', "s", "w", 1);
					if(Move(StockMove))
					{
						commands.push(StockMove);
						system("cls");
					}
					else
					{
						system("cls");
						//cout << RED << "Invalid Command!!!\n\n" << WHITE;
					}
					
				}
				else if (Stockpile.isEmpty())
				{
					system("cls");
					while (!Wastepile.isEmpty())
					{
						Stockpile.push(Wastepile.pop());
					}
				}
			}
			else if (comm[0] == 'm')
			{
				char type = comm[0];
				string src, dest;
				string number;
				int num;
				int i = 1;
				while (comm[i] != ',')
				{
					if (comm[i] != ' ')
						src = src + comm[i];
					i++;
				}
				i++;
				while (comm[i] != ',')
				{
					if (comm[i] != ' ')
						dest = dest + comm[i];
					i++;
				}
				i++;
				while (comm[i] != '\0')
				{
					number = number + comm[i];
					i++;
				}
				num = stoi(number);
				Command move(type, src, dest, num);
				if(Move(move))
				{
					system("cls");
					commands.push(move);
				}
				else
				{
					system("cls");
					cout <<RED<< "Invalid Command\n\n"<<WHITE;
				}
				
			}
			else
			{
				system("cls");
				cout << RED << "Invalid Command\n\n" << WHITE;
			}
		}
		cout << GREEN << "CONGRATULATIONS FOR YOUR WIN !!!!" << WHITE;
	}

};
Game* Game::instance = nullptr;

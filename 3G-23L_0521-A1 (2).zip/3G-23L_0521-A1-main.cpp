#include<iostream>
#include"3G-23L_0521-A1-Cards.h"
#include"3G-23L_0521-A1-Header.h"
#include"3G-23L_0521-A1-Game.h"
using namespace std;
int main()
{
	{
	    Game* solitaire=Game::getInstance();                //Singleton implementation. only one instance can be created
		solitaire->run();                                   //run function
		delete solitaire;                                   // calls destructor to destroy instance
	}
	_CrtDumpMemoryLeaks();                                  //check for memory leaks
}